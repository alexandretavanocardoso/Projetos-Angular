import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-recomendacao',
  templateUrl: './footer-recomendacao.component.html',
  styleUrls: ['./footer-recomendacao.component.css']
})
export class FooterRecomendacaoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
