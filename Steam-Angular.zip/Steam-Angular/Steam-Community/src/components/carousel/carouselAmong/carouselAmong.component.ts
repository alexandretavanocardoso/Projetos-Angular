import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-carouselAmong',
  templateUrl: './carouselAmong.component.html',
  styleUrls: ['./carouselAmong.component.scss']
})
export class CarouselAmongComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
