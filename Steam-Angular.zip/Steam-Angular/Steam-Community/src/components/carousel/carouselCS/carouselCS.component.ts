import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-carouselCS',
  templateUrl: './carouselCS.component.html',
  styleUrls: ['./carouselCS.component.scss']
})
export class CarouselCSComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
