import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-carouselFort',
  templateUrl: './carouselFort.component.html',
  styleUrls: ['./carouselFort.component.scss']
})
export class CarouselFortComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
