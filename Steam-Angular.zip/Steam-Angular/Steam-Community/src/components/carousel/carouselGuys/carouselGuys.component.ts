import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-carouselGuys',
  templateUrl: './carouselGuys.component.html',
  styleUrls: ['./carouselGuys.component.scss']
})
export class CarouselGuysComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
