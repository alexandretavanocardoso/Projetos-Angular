import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buttons-links',
  templateUrl: './buttons-links.component.html',
  styleUrls: ['./buttons-links.component.scss']
})
export class ButtonsLinksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
