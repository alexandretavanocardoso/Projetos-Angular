import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-CardTres',
  templateUrl: './CardTres.component.html',
  styleUrls: ['./CardTres.component.scss']
})
export class CardTresComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
