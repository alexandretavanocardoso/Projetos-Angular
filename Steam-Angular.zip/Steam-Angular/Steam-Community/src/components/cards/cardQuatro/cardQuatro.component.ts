import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cardQuatro',
  templateUrl: './cardQuatro.component.html',
  styleUrls: ['./cardQuatro.component.scss']
})
export class CardQuatroComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
