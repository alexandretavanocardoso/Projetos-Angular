/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { CardUmComponent } from './cardUm.component';

describe('CardUmComponent', () => {
  let component: CardUmComponent;
  let fixture: ComponentFixture<CardUmComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CardUmComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CardUmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
