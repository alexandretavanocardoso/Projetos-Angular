import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cardUm',
  templateUrl: './cardUm.component.html',
  styleUrls: ['./cardUm.component.scss']
})
export class CardUmComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
