import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cardDois',
  templateUrl: './cardDois.component.html',
  styleUrls: ['./cardDois.component.scss']
})
export class CardDoisComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
