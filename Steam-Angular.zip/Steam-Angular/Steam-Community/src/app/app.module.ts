import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from '../header/header.component';
import { NavigationComponent } from '../navigation/navigation.component';
import { FooterRecomendacaoComponent } from '../footer-recomendacao/footer-recomendacao.component';
import { FooterComponent } from '../footer/footer.component';
import { CorpoComponent } from '../corpo/corpo.component';
import { CarouselCSComponent } from '../components/carousel/carouselCS/carouselCS.component';
import { CarouselAmongComponent } from '../components/carousel/carouselAmong/carouselAmong.component';
import { CarouselFortComponent } from '../components/carousel/carouselFort/carouselFort.component';
import { ButtonsLinksComponent } from '../components/buttons/buttons-links/buttons-links.component';
import { CardUmComponent } from '../components/cards/cardUm/cardUm.component';
import { CardDoisComponent } from '../components/cards/cardDois/cardDois.component';
import { CardTresComponent } from '../components/cards/CardTres/CardTres.component';
import { CardQuatroComponent } from '../components/cards/cardQuatro/cardQuatro.component';
import { DropdownComponent } from '../dropdown/dropdown.component';
import { CarouselGuysComponent } from '../components/carousel/carouselGuys/carouselGuys.component';


@NgModule({
  declarations: [							
    AppComponent,
      HeaderComponent,
      NavigationComponent,
      FooterRecomendacaoComponent,
      FooterComponent,
      CorpoComponent,
      CarouselCSComponent,
      CarouselAmongComponent,
      CarouselFortComponent,
      ButtonsLinksComponent,
      CarouselGuysComponent,
      CardUmComponent,
      CardDoisComponent,
      CardTresComponent,
      CardQuatroComponent,
      DropdownComponent
   ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
