import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.scss']
})
export class NavComponent implements OnInit {


  @Input() opened = true;

  constructor() { }

  ngOnInit() {
  }

  toggle(){ 
    this.opened = !this.opened;
  }

}
