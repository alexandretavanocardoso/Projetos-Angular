import { Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'app-videos',
  templateUrl: './videos.component.html',
  styleUrls: ['./videos.component.scss']
})
export class VideosComponent implements OnInit {

  @Input() videos = [
    {
      nomeCanal: 'Angular',
      img: '../../assets/imagens/Angular.png',
      titulo: 'Angular',
      vizualizacoes: '20 mil vizualizações',
      tempo: '° há 5 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'Angular',
      img: '../../assets/imagens/NET.png',
      titulo: '.NET',
      vizualizacoes: '900 mil vizualizações',
      tempo: '° há 5 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'Angular',
      img: '../../assets/imagens/React.png',
      titulo: 'React',
      vizualizacoes: '90 mil vizualizações',
      tempo: '° há 5 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'Angular',
      img: '../../assets/imagens/React.png',
      titulo: 'React Native',
      vizualizacoes: '67 mil vizualizações',
      tempo: '° há 5 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'Angular',
      img: '../../assets/imagens/Database.png',
      titulo: 'SQL Server',
      vizualizacoes: '34 mil vizualizações',
      tempo: '° há 10 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'Angular',
      img: '../../assets/imagens/Database.png',
      titulo: 'MySQL Server',
      vizualizacoes: '102 mil vizualizações',
      tempo: '° há 10 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: '.NET',
      img: '../../assets/imagens/Database.png',
      titulo: 'Oracle',
      vizualizacoes: '278 mil vizualizações',
      tempo: '° há 10 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: '.NET',
      img: '../../assets/imagens/NET.png',
      titulo: '.NET Core',
      vizualizacoes: '234 mil vizualizações',
      tempo: '° há 10 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: '.NET',
      img: '../../assets/imagens/Database.png',
      titulo: 'Database',
      vizualizacoes: '43 mil vizualizações',
      tempo: '° há 10 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: '.NET',
      img: '../../assets/imagens/GIT.png',
      titulo: 'Git',
      vizualizacoes: '3 mil vizualizações',
      tempo: '° há 4 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: '.NET',
      img: '../../assets/imagens/Github.png',
      titulo: 'GitHub',
      vizualizacoes: '6 mil vizualizações',
      tempo: '° há 4 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: '.NET',
      img: '../../assets/imagens/bootstrap.png',
      titulo: 'Bootstrap',
      vizualizacoes: '4 mil vizualizações',
      tempo: '° há 4 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'HTML',
      img: '../../assets/imagens/bootstrap.png',
      titulo: 'Font Awesome',
      vizualizacoes: '5 mil vizualizações',
      tempo: '° há 4 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'HTML',
      img: '../../assets/imagens/JS.png',
      titulo: 'Biblioteca JS',
      vizualizacoes: '202 mil vizualizações',
      tempo: '° há 4 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'HTML',
      img: '../../assets/imagens/JS.png',
      titulo: 'JavaScript',
      vizualizacoes: '23 mil vizualizações',
      tempo: '° há 4 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'C# e SQL Server',
      img: '../../assets/imagens/JS.png',
      titulo: 'jQuery',
      vizualizacoes: '10 mil vizualizações',
      tempo: '° há 78 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'C# e SQL Server',
      img: '../../assets/imagens/html-css.png',
      titulo: 'HTML',
      vizualizacoes: '54 mil vizualizações',
      tempo: '° há 78 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'C# e SQL Server',
      img: '../../assets/imagens/html-css.png',
      titulo: 'CSS',
      vizualizacoes: '65 mil vizualizações',
      tempo: '° há 78 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'C# e SQL Server',
      img: '../../assets/imagens/NET.png',
      titulo: 'Visual Studio',
      vizualizacoes: '25 mil vizualizações',
      tempo: '° há 78 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'C# e SQL Server',
      img: '../../assets/imagens/Code.png',
      titulo: 'Visual Studio Code',
      vizualizacoes: '43 mil vizualizações',
      tempo: '° há 78 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'C# e SQL Server',
      img: '../../assets/imagens/Json.png',
      titulo: 'Json',
      vizualizacoes: '34 mil vizualizações',
      tempo: '° há 78 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'C# e SQL Server',
      img: '../../assets/imagens/git&github.png',
      titulo: 'Git & Github',
      vizualizacoes: '345 mil vizualizações',
      tempo: '° há 78 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'C# e SQL Server',
      img: '../../assets/imagens/html-css.png',
      titulo: 'Templates',
      vizualizacoes: '566 mil vizualizações',
      tempo: '° há 50 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'C# e SQL Server',
      img: '../../assets/imagens/Linkedin.png',
      titulo: 'Como Atualizar seu Linkedin',
      vizualizacoes: '67 mil vizualizações',
      tempo: '° há 50 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'C# e SQL Server',
      img: '../../assets/imagens/Unity.png',
      titulo: 'Unity',
      vizualizacoes: '56 mil vizualizações',
      tempo: '° há 50 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'C# e SQL Server',
      img: '../../assets/imagens/Database.png',
      titulo: 'Banco relacional',
      vizualizacoes: '502 mil vizualizações',
      tempo: '° há 50 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'C# e SQL Server',
      img: '../../assets/imagens/Database.png',
      titulo: 'Banco não relacional',
      vizualizacoes: '34 mil vizualizações',
      tempo: '° há 50 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'C# e SQL Server',
      img: '../../assets/imagens/Unity.png',
      titulo: 'Games',
      vizualizacoes: '56 mil vizualizações',
      tempo: '° há 50 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'C# e SQL Server',
      img: '../../assets/imagens/Unity.png',
      titulo: 'Criação de jogos',
      vizualizacoes: '87 mil vizualizações',
      tempo: '° há 50 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'C# e SQL Server',
      img: '../../assets/imagens/Fluter.png',
      titulo: 'Flluter',
      vizualizacoes: '9 mil vizualizações',
      tempo: '° há 50 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'C# e SQL Server',
      img: '../../assets/imagens/Fluter.png',
      titulo: 'Aplicativos Mobile',
      vizualizacoes: '123 mil vizualizações',
      tempo: '° há 20 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'C# e SQL Server',
      img: '../../assets/imagens/NET.png',
      titulo: 'Dotnet',
      vizualizacoes: '23 mil vizualizações',
      tempo: '° há 20 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'C# e SQL Server',
      img: '../../assets/imagens/Angular.png',
      titulo: 'AngularJS',
      vizualizacoes: '3 mil vizualizações',
      tempo: '° há 20 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'C# e SQL Server',
      img: '../../assets/imagens/NET.png',
      titulo: 'Templates .NET',
      vizualizacoes: '56 mil vizualizações',
      tempo: '° há 20 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'C# e SQL Server',
      img: '../../assets/imagens/Angular.png',
      titulo: 'Templates Angular',
      vizualizacoes: '43 mil vizualizações',
      tempo: '° há 20 dias',
      logo: '../../assets/icones/eu.jpg'
    },
    {
      nomeCanal: 'C# e SQL Server',
      img: '../../assets/imagens/NET.png',
      titulo: 'O que são Componentes?',
      vizualizacoes: '202 mil vizualizações',
      tempo: '° há 20 dias',
      logo: '../../assets/icones/eu.jpg'
    }];

  constructor() { }

  ngOnInit() {
  }

}
