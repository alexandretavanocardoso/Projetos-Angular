import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { VideosComponent } from '../componentes/videos/videos.component';
import { NavComponent } from '../componentes/nav/nav.component';
import { CorpoComponent } from '../componentes/corpo/corpo.component';
 
@NgModule({
  declarations: [
    AppComponent,
    VideosComponent,
    NavComponent,
    CorpoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
